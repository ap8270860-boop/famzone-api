"""
Fixes for what the analyzer will (and did) complain about.

Every one of these is my mistake, not a change of design. Guarded and
idempotent like the apply scripts.

    python fix_location_analyze.py --dry-run
    python fix_location_analyze.py
"""

from __future__ import annotations

import argparse
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent

pending: dict[pathlib.Path, str] = {}
applied: list[str] = []
skipped: list[str] = []
failures: list[str] = []


def read(path: pathlib.Path) -> str:
    return pending.get(path) or path.read_text(encoding="utf-8")


def patch(rel: str, label: str, anchor: str, replacement: str,
          *, expect: int = 1, done_marker: str) -> None:
    path = ROOT / rel

    if not path.exists():
        failures.append(f"{label}: {rel} not found")
        return

    text = read(path)

    if done_marker in text:
        skipped.append(f"{label} (already applied)")
        return

    found = text.count(anchor)

    if found != expect:
        failures.append(f"{label}: anchor found {found}x in {rel}, expected {expect}")
        return

    pending[path] = text.replace(anchor, replacement, expect)
    applied.append(f"{label}  ->  {rel}")


def drop_line(rel: str, label: str, line: str) -> None:
    """Remove an import. Absent already means the job is done, not a failure."""
    path = ROOT / rel

    if not path.exists():
        failures.append(f"{label}: {rel} not found")
        return

    text = read(path)

    if line + "\n" not in text:
        skipped.append(f"{label} (already applied)")
        return

    pending[path] = text.replace(line + "\n", "", 1)
    applied.append(f"{label}  ->  {rel}")


# ---------------------------------------------------------------------------
# 1. The reported error.
#
# MessageLocation lives in the location feature, and Dart imports are not
# transitive — reaching it through chat_models.dart was never going to work.
# ---------------------------------------------------------------------------

patch(
    "lib/features/chat/presentation/widgets/location_bubble.dart",
    "bubble: import MessageLocation",
    "import '../../../location/presentation/live_map_screen.dart';",
    "import '../../../location/data/location_models.dart';\n"
    "import '../../../location/presentation/live_map_screen.dart';",
    done_marker="location/data/location_models.dart",
)


# ---------------------------------------------------------------------------
# 2. zIndex is a double.
#
# `cond ? 2 : 1` is a conditional expression, not an integer literal, so the
# literal-to-double conversion is not guaranteed to apply.
# ---------------------------------------------------------------------------

patch(
    "lib/features/location/presentation/live_map_screen.dart",
    "map: zIndex as double",
    "            zIndex: entry.key == '__me__' ? 2 : 1,",
    "            zIndex: entry.key == '__me__' ? 2.0 : 1.0,",
    done_marker="? 2.0 : 1.0,",
)


# ---------------------------------------------------------------------------
# 3. A real bug, not an analyzer complaint.
#
# _onData rebuilt the marker set without setState, so a first placement —
# somebody appearing on the map who is not moving yet — would not paint until
# something else happened to schedule a frame.
# ---------------------------------------------------------------------------

patch(
    "lib/features/location/presentation/live_map_screen.dart",
    "map: repaint after new data",
    "    _glides.removeWhere((id, _) => !seen.contains(id));\n"
    "\n"
    "    _rebuildMarkers();\n"
    "  }",
    "    _glides.removeWhere((id, _) => !seen.contains(id));\n"
    "\n"
    "    // setState, not a bare call: a first placement is not a movement, so\n"
    "    // the ticker will not fire and nothing else would schedule a frame.\n"
    "    setState(_rebuildMarkers);\n"
    "  }",
    done_marker="a first placement is not a movement",
)


# ---------------------------------------------------------------------------
# 4. firstWhere with a bang on a nullable element.
#
# It leans on flow analysis harder than it needs to. A loop says the same
# thing and cannot be misread by a later reader or a later analyzer.
# ---------------------------------------------------------------------------

patch(
    "lib/features/location/state/location_store.dart",
    "store: familyShare and shareIn as loops",
    """  LocationShare? get familyShare => _myShares
      .cast<LocationShare?>()
      .firstWhere((s) => s!.isFamily && s.active, orElse: () => null);

  /// A share running in one particular thread, if there is one.
  LocationShare? shareIn(String conversationId) => _myShares
      .cast<LocationShare?>()
      .firstWhere(
        (s) => s!.active && s.conversationId == conversationId,
        orElse: () => null,
      );""",
    """  LocationShare? get familyShare {
    for (final share in _myShares) {
      if (share.isFamily && share.active) return share;
    }

    return null;
  }

  /// A share running in one particular thread, if there is one.
  LocationShare? shareIn(String conversationId) {
    for (final share in _myShares) {
      if (share.active && share.conversationId == conversationId) return share;
    }

    return null;
  }""",
    done_marker="if (share.isFamily && share.active) return share;",
)


# ---------------------------------------------------------------------------
# 5. Unused imports.
#
# Future and Stream are re-exported by dart:core, so importing dart:async for
# them is redundant. Warnings rather than errors, but they are noise in an
# analyze run and they are mine.
# ---------------------------------------------------------------------------

drop_line(
    "lib/features/location/state/location_store.dart",
    "store: drop unused dart:async",
    "import 'dart:async';",
)

drop_line(
    "lib/features/location/presentation/live_map_screen.dart",
    "map: drop unused dart:async",
    "import 'dart:async';",
)

drop_line(
    "lib/features/location/presentation/widgets/avatar_marker.dart",
    "marker: drop unused dart:async",
    "import 'dart:async';",
)

drop_line(
    "lib/features/location/presentation/widgets/avatar_marker.dart",
    "marker: drop unused dart:typed_data",
    "import 'dart:typed_data';",
)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    if failures:
        print("\n\033[31mrefusing to write — anchors did not match:\033[0m")

        for line in failures:
            print(f"  \033[31m✗\033[0m {line}")

        return 1

    for line in skipped:
        print(f"  \033[33m·\033[0m {line}")

    for line in applied:
        print(f"  \033[32m✓\033[0m {line}")

    if args.dry_run:
        print("\ndry run — nothing written")

        return 0

    for path, text in pending.items():
        path.write_text(text, encoding="utf-8", newline="\n")

    print(f"\n{len(pending)} files written")

    return 0


if __name__ == "__main__":
    sys.exit(main())
